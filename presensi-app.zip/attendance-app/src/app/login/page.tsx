"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [mode, setMode] = useState<"masuk" | "daftar">("masuk");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);

    if (mode === "masuk") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) {
        setError("Email atau kata sandi salah. Coba lagi.");
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName, role: "guru" } },
      });
      setLoading(false);
      if (error) {
        setError(error.message);
        return;
      }
      setInfo(
        "Akun berhasil dibuat. Jika verifikasi email aktif, cek inbox kamu. Setelah itu masuk lewat tab \"Masuk\"."
      );
      setMode("masuk");
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.1fr_1fr] bg-ink-950">
      {/* Panel kiri — identitas */}
      <div className="relative hidden lg:flex flex-col justify-between p-14 text-chalk-50 overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(90deg, #F7F5EF 0px, #F7F5EF 1px, transparent 1px, transparent 120px), repeating-linear-gradient(0deg, #F7F5EF 0px, #F7F5EF 1px, transparent 1px, transparent 120px)",
          }}
        />
        <div className="relative">
          <span className="font-mono text-xs tracking-[0.25em] text-amber-400">
            PRESENSI · 01
          </span>
          <h1 className="mt-6 font-display text-5xl leading-[1.05] font-semibold">
            Absen kelas,
            <br />
            selesai dalam
            <br />
            satu pindaian.
          </h1>
          <p className="mt-6 max-w-md text-chalk-100/70 text-[15px] leading-relaxed">
            Guru memindai kartu QR siswa, sistem mencatat kehadiran secara
            langsung. Admin mengelola siswa, guru, dan rekapnya dari satu
            dasbor.
          </p>
        </div>
        <div className="relative flex items-center gap-8 font-mono text-xs text-chalk-100/50">
          <span>QR SCAN</span>
          <span className="w-8 h-px bg-chalk-100/30" />
          <span>REKAP OTOMATIS</span>
          <span className="w-8 h-px bg-chalk-100/30" />
          <span>SIAP EKSPOR</span>
        </div>
      </div>

      {/* Panel kanan — form */}
      <div className="flex items-center justify-center p-6 sm:p-10 bg-chalk-50">
        <div className="w-full max-w-sm">
          <div className="lg:hidden mb-8">
            <span className="font-mono text-xs tracking-[0.25em] text-amber-600">
              PRESENSI
            </span>
          </div>

          <div className="flex gap-1 mb-8 border-b border-ink-900/10">
            {(["masuk", "daftar"] as const).map((m) => (
              <button
                key={m}
                onClick={() => {
                  setMode(m);
                  setError(null);
                  setInfo(null);
                }}
                className={`px-1 pb-3 mr-6 text-sm font-medium border-b-2 transition-colors focus-ring ${
                  mode === m
                    ? "border-amber-500 text-ink-950"
                    : "border-transparent text-ink-950/40 hover:text-ink-950/70"
                }`}
              >
                {m === "masuk" ? "Masuk" : "Buat akun"}
              </button>
            ))}
          </div>

          <h2 className="font-display text-2xl font-semibold text-ink-950">
            {mode === "masuk" ? "Selamat datang kembali" : "Buat akun guru"}
          </h2>
          <p className="mt-1.5 text-sm text-ink-950/50">
            {mode === "masuk"
              ? "Masuk dengan email dan kata sandi kamu."
              : "Akun baru mendapat peran Guru. Admin dapat menaikkan peran lewat Supabase."}
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            {mode === "daftar" && (
              <div>
                <label className="block text-xs font-medium text-ink-950/60 mb-1.5">
                  Nama lengkap
                </label>
                <input
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-md border border-ink-900/15 bg-white px-3.5 py-2.5 text-sm text-ink-950 focus-ring"
                  placeholder="Budi Santoso"
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1.5">
                Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-ink-900/15 bg-white px-3.5 py-2.5 text-sm text-ink-950 focus-ring"
                placeholder="guru@sekolahmu.sch.id"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1.5">
                Kata sandi
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-ink-900/15 bg-white px-3.5 py-2.5 text-sm text-ink-950 focus-ring"
                placeholder="Minimal 6 karakter"
              />
            </div>

            {error && (
              <p className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-md px-3 py-2">
                {error}
              </p>
            )}
            {info && (
              <p className="text-sm text-ink-700 bg-amber-400/10 border border-amber-400/30 rounded-md px-3 py-2">
                {info}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2.5 mt-2 hover:bg-ink-900 transition-colors disabled:opacity-50 focus-ring"
            >
              {loading ? "Memproses…" : mode === "masuk" ? "Masuk" : "Buat akun"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
