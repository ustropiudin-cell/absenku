import Link from "next/link";
import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";

export default async function DashboardPage() {
  const profile = await requireProfile();
  const supabase = createClient();
  const today = new Date().toISOString().slice(0, 10);

  const [{ count: totalSiswa }, { count: totalKelas }, { count: hadirHariIni }] =
    await Promise.all([
      supabase.from("siswa").select("*", { count: "exact", head: true }).eq("aktif", true),
      supabase.from("kelas").select("*", { count: "exact", head: true }),
      supabase
        .from("presensi")
        .select("*", { count: "exact", head: true })
        .eq("tanggal", today),
    ]);

  const { data: presensiTerbaru } = await supabase
    .from("presensi")
    .select("id, waktu_scan, status, siswa:siswa_id(nama), kelas:kelas_id(nama_kelas), mapel:mapel_id(nama_mapel)")
    .eq("tanggal", today)
    .order("waktu_scan", { ascending: false })
    .limit(8);

  const stats = [
    { label: "Siswa aktif", value: totalSiswa ?? 0 },
    { label: "Total kelas", value: totalKelas ?? 0 },
    { label: "Presensi hari ini", value: hadirHariIni ?? 0 },
  ];

  return (
    <div>
      <PageHeader
        eyebrow="RINGKASAN"
        title={`Halo, ${profile.full_name.split(" ")[0]}`}
        description={`Hari ini, ${new Date().toLocaleDateString("id-ID", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
        })}.`}
        action={
          <Link
            href="/dashboard/presensi"
            className="rounded-md bg-ink-950 text-chalk-50 text-sm font-medium px-4 py-2.5 hover:bg-ink-900 transition-colors"
          >
            Mulai presensi
          </Link>
        }
      />

      <div className="p-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-lg border border-ink-900/10 bg-white p-5"
            >
              <p className="text-xs font-medium text-ink-950/50">{s.label}</p>
              <p className="font-display text-3xl font-semibold text-ink-950 mt-2">
                {s.value}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-8">
          <h2 className="text-sm font-semibold text-ink-950 mb-3">
            Aktivitas presensi hari ini
          </h2>
          <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden">
            {!presensiTerbaru || presensiTerbaru.length === 0 ? (
              <p className="text-sm text-ink-950/40 px-5 py-8 text-center">
                Belum ada presensi tercatat hari ini.
              </p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
                    <th className="px-5 py-3 font-medium">Waktu</th>
                    <th className="px-5 py-3 font-medium">Siswa</th>
                    <th className="px-5 py-3 font-medium">Kelas</th>
                    <th className="px-5 py-3 font-medium">Mapel</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {presensiTerbaru.map((p: any) => (
                    <tr key={p.id} className="border-b border-ink-900/5 last:border-0">
                      <td className="px-5 py-3 font-mono text-xs text-ink-950/60">
                        {new Date(p.waktu_scan).toLocaleTimeString("id-ID", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </td>
                      <td className="px-5 py-3 text-ink-950">{p.siswa?.nama}</td>
                      <td className="px-5 py-3 text-ink-950/70">{p.kelas?.nama_kelas}</td>
                      <td className="px-5 py-3 text-ink-950/70">{p.mapel?.nama_mapel ?? "—"}</td>
                      <td className="px-5 py-3">
                        <span className="inline-block rounded-sm bg-amber-400/15 text-amber-600 text-xs font-medium px-2 py-0.5 capitalize">
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
