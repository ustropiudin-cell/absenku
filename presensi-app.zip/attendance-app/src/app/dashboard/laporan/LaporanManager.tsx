"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { exportExcel, type LaporanRow } from "@/lib/export/excel";
import { exportPdf } from "@/lib/export/pdf";

type Kelas = { id: string; nama_kelas: string };
type Mapel = { id: string; nama_mapel: string };

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function firstOfMonthStr() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export default function LaporanManager({
  kelasList,
  mapelList,
}: {
  kelasList: Kelas[];
  mapelList: Mapel[];
}) {
  const supabase = createClient();

  const [dariTanggal, setDariTanggal] = useState(firstOfMonthStr());
  const [sampaiTanggal, setSampaiTanggal] = useState(todayStr());
  const [kelasId, setKelasId] = useState("semua");
  const [mapelId, setMapelId] = useState("semua");
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<LaporanRow[]>([]);
  const [searched, setSearched] = useState(false);

  async function handleSearch() {
    setLoading(true);
    let query = supabase
      .from("presensi")
      .select("tanggal, waktu_scan, status, siswa:siswa_id(nis, nama), kelas:kelas_id(nama_kelas), mapel:mapel_id(nama_mapel)")
      .gte("tanggal", dariTanggal)
      .lte("tanggal", sampaiTanggal)
      .order("tanggal", { ascending: false })
      .order("waktu_scan", { ascending: false });

    if (kelasId !== "semua") query = query.eq("kelas_id", kelasId);
    if (mapelId !== "semua") query = query.eq("mapel_id", mapelId);

    const { data } = await query;

    const mapped: LaporanRow[] = (data ?? []).map((p: any) => ({
      tanggal: p.tanggal,
      nis: p.siswa?.nis ?? "—",
      nama: p.siswa?.nama ?? "—",
      kelas: p.kelas?.nama_kelas ?? "—",
      mapel: p.mapel?.nama_mapel ?? "—",
      status: p.status,
      waktu: new Date(p.waktu_scan).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }),
    }));

    setRows(mapped);
    setSearched(true);
    setLoading(false);
  }

  const fileBase = `rekap-presensi_${dariTanggal}_${sampaiTanggal}`;

  return (
    <div className="p-8">
      <div className="rounded-lg border border-ink-900/10 bg-white p-5 mb-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
          <div>
            <label className="block text-xs font-medium text-ink-950/60 mb-1">Dari tanggal</label>
            <input
              type="date"
              value={dariTanggal}
              onChange={(e) => setDariTanggal(e.target.value)}
              className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-ink-950/60 mb-1">Sampai tanggal</label>
            <input
              type="date"
              value={sampaiTanggal}
              onChange={(e) => setSampaiTanggal(e.target.value)}
              className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-ink-950/60 mb-1">Kelas</label>
            <select
              value={kelasId}
              onChange={(e) => setKelasId(e.target.value)}
              className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring"
            >
              <option value="semua">Semua kelas</option>
              {kelasList.map((k) => <option key={k.id} value={k.id}>{k.nama_kelas}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-ink-950/60 mb-1">Mapel</label>
            <select
              value={mapelId}
              onChange={(e) => setMapelId(e.target.value)}
              className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring"
            >
              <option value="semua">Semua mapel</option>
              {mapelList.map((m) => <option key={m.id} value={m.id}>{m.nama_mapel}</option>)}
            </select>
          </div>
          <button
            onClick={handleSearch}
            disabled={loading}
            className="rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2.5 hover:bg-ink-900 disabled:opacity-50"
          >
            {loading ? "Memuat…" : "Tampilkan"}
          </button>
        </div>
      </div>

      {searched && (
        <>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs text-ink-950/40">{rows.length} baris presensi</span>
            <div className="ml-auto flex gap-2">
              <button
                onClick={() => exportExcel(rows, fileBase)}
                disabled={rows.length === 0}
                className="rounded-md border border-ink-900/15 text-sm font-medium px-4 py-2 hover:bg-ink-950/5 disabled:opacity-40"
              >
                Ekspor Excel
              </button>
              <button
                onClick={() => exportPdf(rows, "Rekap Presensi", fileBase)}
                disabled={rows.length === 0}
                className="rounded-md border border-ink-900/15 text-sm font-medium px-4 py-2 hover:bg-ink-950/5 disabled:opacity-40"
              >
                Ekspor PDF
              </button>
            </div>
          </div>

          <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden">
            {rows.length === 0 ? (
              <p className="text-sm text-ink-950/40 px-5 py-10 text-center">
                Tidak ada data presensi pada rentang dan filter ini.
              </p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
                    <th className="px-5 py-3 font-medium">Tanggal</th>
                    <th className="px-5 py-3 font-medium">NIS</th>
                    <th className="px-5 py-3 font-medium">Nama</th>
                    <th className="px-5 py-3 font-medium">Kelas</th>
                    <th className="px-5 py-3 font-medium">Mapel</th>
                    <th className="px-5 py-3 font-medium">Waktu</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i} className="border-b border-ink-900/5 last:border-0">
                      <td className="px-5 py-2.5 font-mono text-xs text-ink-950/60">{r.tanggal}</td>
                      <td className="px-5 py-2.5 font-mono text-xs text-ink-950/60">{r.nis}</td>
                      <td className="px-5 py-2.5 text-ink-950 font-medium">{r.nama}</td>
                      <td className="px-5 py-2.5 text-ink-950/70">{r.kelas}</td>
                      <td className="px-5 py-2.5 text-ink-950/70">{r.mapel}</td>
                      <td className="px-5 py-2.5 text-ink-950/70">{r.waktu}</td>
                      <td className="px-5 py-2.5">
                        <span className="inline-block rounded-sm bg-amber-400/15 text-amber-700 text-xs font-medium px-2 py-0.5 capitalize">
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </div>
  );
}
