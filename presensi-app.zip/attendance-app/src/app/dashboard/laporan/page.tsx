import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";
import LaporanManager from "./LaporanManager";

export default async function LaporanPage() {
  await requireProfile();
  const supabase = createClient();

  const [{ data: kelas }, { data: mapel }] = await Promise.all([
    supabase.from("kelas").select("id, nama_kelas").order("nama_kelas"),
    supabase.from("mapel").select("id, nama_mapel").order("nama_mapel"),
  ]);

  return (
    <div>
      <PageHeader
        eyebrow="LAPORAN"
        title="Rekap Presensi"
        description="Lihat riwayat presensi lalu ekspor ke Excel atau PDF."
      />
      <LaporanManager kelasList={kelas ?? []} mapelList={mapel ?? []} />
    </div>
  );
}
