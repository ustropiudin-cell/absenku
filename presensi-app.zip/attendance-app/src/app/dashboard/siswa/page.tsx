import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";
import SiswaManager from "./SiswaManager";

export default async function SiswaPage() {
  await requireAdmin();
  const supabase = createClient();

  const [{ data: siswa }, { data: kelas }] = await Promise.all([
    supabase
      .from("siswa")
      .select("id, nis, nama, kelas_id, aktif, qr_code, kelas:kelas_id(nama_kelas)")
      .order("nama"),
    supabase.from("kelas").select("id, nama_kelas").order("nama_kelas"),
  ]);

  return (
    <div>
      <PageHeader
        eyebrow="DATA SISWA"
        title="Siswa"
        description="Kelola data siswa dan penempatan kelasnya. Kode QR dibuat otomatis."
      />
      <SiswaManager
        initialSiswa={(siswa as any) ?? []}
        kelasList={kelas ?? []}
      />
    </div>
  );
}
