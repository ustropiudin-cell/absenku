import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";
import KartuPrinter from "./KartuPrinter";

export default async function KartuPage() {
  await requireAdmin();
  const supabase = createClient();

  const [{ data: siswa }, { data: kelas }] = await Promise.all([
    supabase
      .from("siswa")
      .select("id, nis, nama, kelas_id, qr_code, kelas:kelas_id(nama_kelas)")
      .eq("aktif", true)
      .order("nama"),
    supabase.from("kelas").select("id, nama_kelas").order("nama_kelas"),
  ]);

  return (
    <div>
      <PageHeader
        eyebrow="CETAK"
        title="Kartu QR Siswa"
        description="Cetak kartu berisi kode QR unik untuk setiap siswa, dipindai guru saat presensi."
      />
      <KartuPrinter initialSiswa={(siswa as any) ?? []} kelasList={kelas ?? []} />
    </div>
  );
}
