"use client";

import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";

type Kelas = { id: string; nama_kelas: string };
type Siswa = { id: string; nis: string; nama: string; kelas_id: string | null; qr_code: string; kelas: { nama_kelas: string } | null };

export default function KartuPrinter({
  initialSiswa,
  kelasList,
}: {
  initialSiswa: Siswa[];
  kelasList: Kelas[];
}) {
  const [filterKelas, setFilterKelas] = useState("semua");

  const filtered = initialSiswa.filter(
    (s) => filterKelas === "semua" || s.kelas_id === filterKelas
  );

  return (
    <div className="p-8">
      <div className="no-print flex flex-wrap items-center gap-3 mb-6">
        <select
          value={filterKelas}
          onChange={(e) => setFilterKelas(e.target.value)}
          className="rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring"
        >
          <option value="semua">Semua kelas</option>
          {kelasList.map((k) => (
            <option key={k.id} value={k.id}>{k.nama_kelas}</option>
          ))}
        </select>
        <span className="text-xs text-ink-950/40">{filtered.length} kartu</span>
        <button
          onClick={() => window.print()}
          className="ml-auto rounded-md bg-ink-950 text-chalk-50 text-sm font-medium px-4 py-2 hover:bg-ink-900"
        >
          Cetak kartu
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-lg border border-dashed border-ink-900/20 bg-white p-10 text-center text-sm text-ink-950/50">
          Tidak ada siswa untuk ditampilkan.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 print:grid-cols-3 print:gap-3">
          {filtered.map((s) => (
            <div
              key={s.id}
              className="rounded-lg border border-ink-900/15 bg-white p-4 flex flex-col items-center text-center break-inside-avoid"
            >
              <span className="font-mono text-[10px] tracking-[0.2em] text-amber-600 mb-2">
                KARTU PRESENSI
              </span>
              <QRCodeSVG value={s.qr_code} size={112} level="M" />
              <p className="mt-3 text-sm font-semibold text-ink-950 leading-tight">{s.nama}</p>
              <p className="text-xs text-ink-950/50 mt-0.5">
                NIS {s.nis} · {s.kelas?.nama_kelas ?? "—"}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
