import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";
import GuruManager from "./GuruManager";

export default async function GuruPage() {
  await requireAdmin();
  const supabase = createClient();

  const { data: guru } = await supabase
    .from("profiles")
    .select("id, full_name, email, created_at")
    .eq("role", "guru")
    .order("full_name");

  return (
    <div>
      <PageHeader
        eyebrow="AKUN"
        title="Akun Guru"
        description="Buat dan kelola akun masuk untuk para guru."
      />
      <GuruManager initialGuru={guru ?? []} />
    </div>
  );
}
