"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Guru = { id: string; full_name: string; email: string; created_at: string };

export default function GuruManager({ initialGuru }: { initialGuru: Guru[] }) {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/guru", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ full_name: fullName, email, password }),
    });
    const body = await res.json();
    setSaving(false);

    if (!res.ok) {
      setError(body.error ?? "Gagal membuat akun guru.");
      return;
    }

    setFullName("");
    setEmail("");
    setPassword("");
    router.refresh();
  }

  async function handleDelete(g: Guru) {
    if (!confirm(`Hapus akun guru "${g.full_name}"? Jadwal dan presensinya tetap tersimpan.`)) return;
    const res = await fetch("/api/guru", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: g.id }),
    });
    if (!res.ok) {
      const body = await res.json();
      alert(body.error ?? "Gagal menghapus akun.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="p-8 grid lg:grid-cols-[320px_1fr] gap-6">
      <form onSubmit={handleSubmit} className="rounded-lg border border-ink-900/10 bg-white p-5 h-fit space-y-3">
        <h2 className="text-sm font-semibold text-ink-950">Buat akun guru</h2>
        <div>
          <label className="block text-xs font-medium text-ink-950/60 mb-1">Nama lengkap</label>
          <input
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
            placeholder="Nama guru"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-ink-950/60 mb-1">Email</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
            placeholder="guru@sekolahmu.sch.id"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-ink-950/60 mb-1">Kata sandi awal</label>
          <input
            required
            minLength={6}
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
            placeholder="Minimal 6 karakter"
          />
        </div>
        {error && <p className="text-xs text-red-600">{error}</p>}
        <button
          disabled={saving}
          className="w-full rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2 hover:bg-ink-900 disabled:opacity-50"
        >
          {saving ? "Membuat…" : "Buat akun"}
        </button>
        <p className="text-xs text-ink-950/40">
          Bagikan email dan kata sandi ini ke guru terkait. Mereka bisa menggantinya nanti.
        </p>
      </form>

      <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden h-fit">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
              <th className="px-5 py-3 font-medium">Nama</th>
              <th className="px-5 py-3 font-medium">Email</th>
              <th className="px-5 py-3 font-medium text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {initialGuru.length === 0 && (
              <tr>
                <td colSpan={3} className="px-5 py-8 text-center text-ink-950/40">
                  Belum ada akun guru.
                </td>
              </tr>
            )}
            {initialGuru.map((g) => (
              <tr key={g.id} className="border-b border-ink-900/5 last:border-0">
                <td className="px-5 py-3 font-medium text-ink-950">{g.full_name}</td>
                <td className="px-5 py-3 text-ink-950/70">{g.email}</td>
                <td className="px-5 py-3 text-right">
                  <button onClick={() => handleDelete(g)} className="text-xs font-medium text-red-500 hover:text-red-700">
                    Hapus
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
