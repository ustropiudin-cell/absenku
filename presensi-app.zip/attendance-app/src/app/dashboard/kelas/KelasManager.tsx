"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type Guru = { id: string; full_name: string };
type Kelas = { id: string; nama_kelas: string; wali_kelas_id: string | null; wali: { full_name: string } | null };
type Mapel = { id: string; nama_mapel: string; kode: string | null };
type Jadwal = {
  id: string;
  hari: string;
  jam_mulai: string;
  jam_selesai: string;
  kelas: { nama_kelas: string } | null;
  mapel: { nama_mapel: string } | null;
  guru: { full_name: string } | null;
};

const HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

export default function KelasManager({
  initialKelas,
  initialMapel,
  initialJadwal,
  guruList,
}: {
  initialKelas: Kelas[];
  initialMapel: Mapel[];
  initialJadwal: Jadwal[];
  guruList: Guru[];
}) {
  const router = useRouter();
  const supabase = createClient();
  const [tab, setTab] = useState<"kelas" | "mapel" | "jadwal">("kelas");

  // form kelas
  const [namaKelas, setNamaKelas] = useState("");
  const [waliId, setWaliId] = useState("");
  // form mapel
  const [namaMapel, setNamaMapel] = useState("");
  const [kodeMapel, setKodeMapel] = useState("");
  // form jadwal
  const [jKelas, setJKelas] = useState(initialKelas[0]?.id ?? "");
  const [jMapel, setJMapel] = useState(initialMapel[0]?.id ?? "");
  const [jGuru, setJGuru] = useState(guruList[0]?.id ?? "");
  const [jHari, setJHari] = useState("Senin");
  const [jMulai, setJMulai] = useState("07:00");
  const [jSelesai, setJSelesai] = useState("08:30");

  async function addKelas(e: React.FormEvent) {
    e.preventDefault();
    await supabase.from("kelas").insert({ nama_kelas: namaKelas, wali_kelas_id: waliId || null });
    setNamaKelas("");
    setWaliId("");
    router.refresh();
  }
  async function deleteKelas(id: string) {
    if (!confirm("Hapus kelas ini? Siswa di kelas ini akan kehilangan kelasnya.")) return;
    await supabase.from("kelas").delete().eq("id", id);
    router.refresh();
  }

  async function addMapel(e: React.FormEvent) {
    e.preventDefault();
    await supabase.from("mapel").insert({ nama_mapel: namaMapel, kode: kodeMapel || null });
    setNamaMapel("");
    setKodeMapel("");
    router.refresh();
  }
  async function deleteMapel(id: string) {
    if (!confirm("Hapus mata pelajaran ini?")) return;
    await supabase.from("mapel").delete().eq("id", id);
    router.refresh();
  }

  async function addJadwal(e: React.FormEvent) {
    e.preventDefault();
    if (!jKelas || !jMapel || !jGuru) return;
    await supabase.from("jadwal").insert({
      kelas_id: jKelas,
      mapel_id: jMapel,
      guru_id: jGuru,
      hari: jHari,
      jam_mulai: jMulai,
      jam_selesai: jSelesai,
    });
    router.refresh();
  }
  async function deleteJadwal(id: string) {
    if (!confirm("Hapus jadwal ini?")) return;
    await supabase.from("jadwal").delete().eq("id", id);
    router.refresh();
  }

  return (
    <div className="p-8">
      <div className="flex gap-1 mb-6 border-b border-ink-900/10">
        {(["kelas", "mapel", "jadwal"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-1 pb-3 mr-6 text-sm font-medium border-b-2 capitalize transition-colors ${
              tab === t ? "border-amber-500 text-ink-950" : "border-transparent text-ink-950/40"
            }`}
          >
            {t === "kelas" ? "Kelas" : t === "mapel" ? "Mata Pelajaran" : "Jadwal"}
          </button>
        ))}
      </div>

      {tab === "kelas" && (
        <div className="grid lg:grid-cols-[320px_1fr] gap-6">
          <form onSubmit={addKelas} className="rounded-lg border border-ink-900/10 bg-white p-5 h-fit space-y-3">
            <h2 className="text-sm font-semibold text-ink-950">Tambah kelas</h2>
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1">Nama kelas</label>
              <input
                required
                value={namaKelas}
                onChange={(e) => setNamaKelas(e.target.value)}
                placeholder="Contoh: VII-A"
                className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1">Wali kelas</label>
              <select
                value={waliId}
                onChange={(e) => setWaliId(e.target.value)}
                className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring"
              >
                <option value="">Belum ditentukan</option>
                {guruList.map((g) => (
                  <option key={g.id} value={g.id}>{g.full_name}</option>
                ))}
              </select>
            </div>
            <button className="w-full rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2 hover:bg-ink-900">
              Tambah kelas
            </button>
          </form>

          <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden h-fit">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
                  <th className="px-5 py-3 font-medium">Kelas</th>
                  <th className="px-5 py-3 font-medium">Wali kelas</th>
                  <th className="px-5 py-3 font-medium text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {initialKelas.map((k) => (
                  <tr key={k.id} className="border-b border-ink-900/5 last:border-0">
                    <td className="px-5 py-3 font-medium text-ink-950">{k.nama_kelas}</td>
                    <td className="px-5 py-3 text-ink-950/70">{k.wali?.full_name ?? "—"}</td>
                    <td className="px-5 py-3 text-right">
                      <button onClick={() => deleteKelas(k.id)} className="text-xs font-medium text-red-500 hover:text-red-700">
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "mapel" && (
        <div className="grid lg:grid-cols-[320px_1fr] gap-6">
          <form onSubmit={addMapel} className="rounded-lg border border-ink-900/10 bg-white p-5 h-fit space-y-3">
            <h2 className="text-sm font-semibold text-ink-950">Tambah mata pelajaran</h2>
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1">Nama mapel</label>
              <input
                required
                value={namaMapel}
                onChange={(e) => setNamaMapel(e.target.value)}
                placeholder="Contoh: Matematika"
                className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-950/60 mb-1">Kode (opsional)</label>
              <input
                value={kodeMapel}
                onChange={(e) => setKodeMapel(e.target.value)}
                placeholder="Contoh: MTK"
                className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring"
              />
            </div>
            <button className="w-full rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2 hover:bg-ink-900">
              Tambah mapel
            </button>
          </form>

          <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden h-fit">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
                  <th className="px-5 py-3 font-medium">Mapel</th>
                  <th className="px-5 py-3 font-medium">Kode</th>
                  <th className="px-5 py-3 font-medium text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {initialMapel.map((m) => (
                  <tr key={m.id} className="border-b border-ink-900/5 last:border-0">
                    <td className="px-5 py-3 font-medium text-ink-950">{m.nama_mapel}</td>
                    <td className="px-5 py-3 text-ink-950/70">{m.kode ?? "—"}</td>
                    <td className="px-5 py-3 text-right">
                      <button onClick={() => deleteMapel(m.id)} className="text-xs font-medium text-red-500 hover:text-red-700">
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "jadwal" && (
        <div className="grid lg:grid-cols-[320px_1fr] gap-6">
          <form onSubmit={addJadwal} className="rounded-lg border border-ink-900/10 bg-white p-5 h-fit space-y-3">
            <h2 className="text-sm font-semibold text-ink-950">Tambah jadwal</h2>
            <select value={jKelas} onChange={(e) => setJKelas(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring">
              {initialKelas.map((k) => <option key={k.id} value={k.id}>{k.nama_kelas}</option>)}
            </select>
            <select value={jMapel} onChange={(e) => setJMapel(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring">
              {initialMapel.map((m) => <option key={m.id} value={m.id}>{m.nama_mapel}</option>)}
            </select>
            <select value={jGuru} onChange={(e) => setJGuru(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring">
              {guruList.map((g) => <option key={g.id} value={g.id}>{g.full_name}</option>)}
            </select>
            <select value={jHari} onChange={(e) => setJHari(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm bg-white focus-ring">
              {HARI.map((h) => <option key={h} value={h}>{h}</option>)}
            </select>
            <div className="flex gap-2">
              <input type="time" value={jMulai} onChange={(e) => setJMulai(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring" />
              <input type="time" value={jSelesai} onChange={(e) => setJSelesai(e.target.value)} className="w-full rounded-md border border-ink-900/15 px-3 py-2 text-sm focus-ring" />
            </div>
            <button className="w-full rounded-md bg-ink-950 text-chalk-50 text-sm font-medium py-2 hover:bg-ink-900">
              Tambah jadwal
            </button>
          </form>

          <div className="rounded-lg border border-ink-900/10 bg-white overflow-hidden h-fit">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-900/10 text-left text-ink-950/50">
                  <th className="px-5 py-3 font-medium">Hari</th>
                  <th className="px-5 py-3 font-medium">Jam</th>
                  <th className="px-5 py-3 font-medium">Kelas</th>
                  <th className="px-5 py-3 font-medium">Mapel</th>
                  <th className="px-5 py-3 font-medium">Guru</th>
                  <th className="px-5 py-3 font-medium text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {initialJadwal.map((j) => (
                  <tr key={j.id} className="border-b border-ink-900/5 last:border-0">
                    <td className="px-5 py-3 text-ink-950">{j.hari}</td>
                    <td className="px-5 py-3 font-mono text-xs text-ink-950/60">{j.jam_mulai.slice(0,5)}–{j.jam_selesai.slice(0,5)}</td>
                    <td className="px-5 py-3 text-ink-950/70">{j.kelas?.nama_kelas}</td>
                    <td className="px-5 py-3 text-ink-950/70">{j.mapel?.nama_mapel}</td>
                    <td className="px-5 py-3 text-ink-950/70">{j.guru?.full_name}</td>
                    <td className="px-5 py-3 text-right">
                      <button onClick={() => deleteJadwal(j.id)} className="text-xs font-medium text-red-500 hover:text-red-700">
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
