import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import PageHeader from "@/components/PageHeader";
import KelasManager from "./KelasManager";

export default async function KelasPage() {
  await requireAdmin();
  const supabase = createClient();

  const [{ data: kelas }, { data: mapel }, { data: jadwal }, { data: guru }] =
    await Promise.all([
      supabase.from("kelas").select("id, nama_kelas, wali_kelas_id, wali:wali_kelas_id(full_name)").order("nama_kelas"),
      supabase.from("mapel").select("id, nama_mapel, kode").order("nama_mapel"),
      supabase
        .from("jadwal")
        .select("id, hari, jam_mulai, jam_selesai, kelas:kelas_id(nama_kelas), mapel:mapel_id(nama_mapel), guru:guru_id(full_name)")
        .order("hari"),
      supabase.from("profiles").select("id, full_name").eq("role", "guru").order("full_name"),
    ]);

  return (
    <div>
      <PageHeader
        eyebrow="AKADEMIK"
        title="Kelas & Mata Pelajaran"
        description="Atur kelas, mata pelajaran, dan jadwal mengajar guru."
      />
      <KelasManager
        initialKelas={(kelas as any) ?? []}
        initialMapel={mapel ?? []}
        initialJadwal={(jadwal as any) ?? []}
        guruList={guru ?? []}
      />
    </div>
  );
}
