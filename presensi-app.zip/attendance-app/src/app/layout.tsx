import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Presensi | Sekolah",
  description: "Aplikasi presensi online berbasis QR Code untuk guru dan admin sekolah.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
